# SimpleFusion
Official PyTorch Implementation of [SimpleFusion: A Simple Fusion Framework for
Infrared and Visible Images](https://arxiv.org/abs/2), Accepted by PRCV 2024

