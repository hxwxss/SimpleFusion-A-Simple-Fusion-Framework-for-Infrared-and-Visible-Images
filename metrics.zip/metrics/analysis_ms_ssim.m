function [oQ, Q, qMap] = analysis_ms_ssim(imgSeq, fI, K, window, level, weight)


if (nargin < 2 || nargin > 6)
   oQ = -Inf;
   Q = -Inf;
   qMap = -Inf;
   return;
end

if (~exist('K', 'var'))
   K = 0.03;
end

if (~exist('window', 'var'))
   window = fspecial('gaussian', 11, 1.5);
end

[H, W] = size(window);

if (~exist('level','var'))
   level = 3;
end

if (~exist('weight', 'var'))
   weight = [0.0448  0.2856  0.3001]'; 
   weight = weight / sum(weight);
end

if level ~= length(weight)
   oQ = -Inf;
   Q = -Inf;
   qMap = -Inf;
   return;
end

[s1, s2, s3] = size(imgSeq);
minImgWidth = min(s1, s2)/(2^(level-1));
maxWinWidth = max(H, W);
if (minImgWidth < maxWinWidth)
   oQ = -Inf;
   Q = -Inf;
   qMap = Inf;
   return;
end

imgSeq = double(imgSeq);
fI = double(fI);
downsampleFilter = ones(2)./4;
Q = zeros(level,1);
qMap = cell(level,1);
if level == 1
    [Q, qMap] = mef_ssim(imgSeq, fI,  K, window);
    oQ = Q;
    return;
else
    for l = 1 : level - 1
        [Q(l), qMap{l}] = mef_ssim(imgSeq, fI,  K, window); 
        imgSeqC = imgSeq;
        clear imgSeq;
        for i = 1:s3
            rI = squeeze(imgSeqC(:,:,i));
            dI = imfilter(rI, downsampleFilter, 'symmetric', 'same');
            imgSeq(:,:,i) = dI(1:2:end, 1:2:end);
        end
        dI = imfilter(fI, downsampleFilter, 'symmetric', 'same');
        clear fI;
        fI = dI(1:2:end, 1:2:end);
    end
    % the coarsest scale
    [Q(level), qMap{level}] = mef_ssim(imgSeq, fI,  K, window);
    Q = Q(:);
    oQ = prod(Q.^weight);
end

