% script for analyse the fused images

clear all;
clc;

% Total number of images
num = 40;

% Specify the folder path
folderPath = 'path/to/your/test_set/source/infrared/images';

% Use the dir function to get information on all files in the folder
fileList = dir(folderPath);

% Initialize an empty cell array to store file names
fileNames = cell(1, numel(fileList));

% Loop through the file list and extract file names
for i = 1:numel(fileList)
    % Ensure the current item is not a directory
    if ~fileList(i).isdir
        % Extract the file name and store it in the cell array
        fileNames{i} = fileList(i).name;
    end
end

% Remove empty cells
fileNames = fileNames(~cellfun('isempty', fileNames));

% Initialize metrics
EN = 0;
SD = 0;
MI = 0;
Nabf = 0;

% Loop through the specified number of images
for i = 1:num
    % Construct the source infrared image file path
    fileName_source_l = ['./images/test_set/ir/', fileNames{i}];
    
    % Replace 'IR' with 'VIS' in the file name for the visible light image
    nameString = strrep(fileNames{i}, 'IR', 'VIS'); 
    
    % Construct the source visible light image file path
    fileName_source_r = ['./images/test_set/vis/', nameString];
    
    % Replace 'bmp' with 'png' in the file name for the fused image
    nameString1 = strrep(fileNames{i}, 'bmp', 'png'); 
    % Replace 'jpg' with 'png' in the file name for the fused image
    nameString1 = strrep(nameString1, 'jpg', 'png'); 

    % Construct the fused image file path
    fileName_fused = ['./images/Outpu/', nameString1];

    % Read the images
    fused_image = imread(fileName_fused);
    sourceTestImage1 = imread(fileName_source_l);
    sourceTestImage2 = imread(fileName_source_r);
    
    % Analyze the reference metrics
    metrics = analysis_Reference(fused_image, sourceTestImage1, sourceTestImage2);
    
    % Accumulate the metrics
    EN = EN + metrics.EN;
    SD = SD + metrics.SD;
    MI = MI + metrics.MI;
    Nabf = Nabf + metrics.Nabf;
end

% Compute the average metrics
num = numel(fileList);
EN = EN / num;
SD = SD / num;
MI = MI / num;
Nabf = Nabf / num;


% Display the metrics
disp(['EN: ', num2str(EN), ', SD: ', num2str(SD), ', MI: ', num2str(MI), ...
    ', Nabf: ', num2str(Nabf)]);

































